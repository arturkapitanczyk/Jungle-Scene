=======================================================
Date:             11th of January 2001.
file:             sb-frozenduskjpg.zip
author:           Sock 
email address:    sock@planetquake.com
URL:              http://www.planetquake.com/simland

=======================================================

Instructions for using the Frozen Dusk Skybox
---------------------------------------------

** You must have installed the Q3 editor tools first **


1. Extract the zip at in the BASEQ3 directory.
   The zip file has all the directory structure in
   place ready for the above location.
   
2. Goto the SCRIPTS sub-directory under the BASEQ3
   directory and find the following 
   file :- SHADERLIST.TXT.
   
3. Open this file up in a text editor and add the
   following line at the bottom of the file.
   
   FROZENDUSK
   
4. Close the file and open Q3Radiant and you should
   find on the texture menu the FROZENDUSK subdirectory.
   
5. Choose the FROZENDUSK subdirectory and you should find
   the sky texture ready for use.
   
6. If the editor displays 2 textures use the one
   called FROZENDUSK_SKYBOX. The other one is just so
   that you have something to remind you of what
   you are inserting into your map.
   
Enjoy
Sock